# COEFICIENT + Leaf Literature Agent — Session Handoff

**תאריך:** 2026-07-15
**מחשב מקור:** תחנת עבודה (משרד)
**ממשיכים מ:** מחשב נייד בעבודה
**פרויקט:** הצעת מחקר COEFICIENT (off-flavor reduction in leaf-protein processing) + סוכן סקר הספרות
**מיקום:** `Analysis_Workspace/Leaf_Protein_Extraction/Research_Proposals/COEFICIENT/`
**סוכן ספרות:** `Analysis_Workspace/Leaf_Literature_Agent/`

---

## מה נעשה בסשן הקודם (ריצת הסקר, לילה 15.07)
- אשכול חדש `lox_leaf_protein_sensory`, 7 שאילתות, הושלם במלואו (לא נקטע למרות סגירת הטרמינלים).
- נוספו 45 מאמרים (43 טקסט מלא, 1 בתור ל-PDF, 1 כפילות); 44 PDF מופו.
- חילוץ: 161 שורות טבלה מ-28 מאמרים, 64 איורים מ-21 מאמרים, 12 מועמדים מספריים מ-3 מאמרים לביקורת.
- הרמוניזציה + auto-ingest הושלמו. `integrity_check = ok`.
- נוצר `agent/build_citation_library.py` → `references/coeficient_library.bib` + `.ris`.
- run_state: `last_literature_search = last_auto_ingest = last_extract_store = last_harmonization = 2026-07-15`.

## מה נעשה בסשן הזה (ביקורת התוצרים)
**12 המועמדים המספריים — 0 לקידום.** קובץ: `db/evidence_staging/numeric_review.jsonl`
- לכולם חסרים `unit` / `species` / `treatment_condition` → לא ניתן לאמת.
- foodchem_2023_137924 Table 2 שורה 8 (פריטים 1-3): פרסור עמודות שגוי, SD גדול מהממוצע פי מאות (`1001.2±1018.2`, `5.5±722.2`). דורש קריאה ידנית של הטבלה.
- foods13213423 Table 3 "שורה 1" (פריטים 4-11): 8 ערכים משורה אחת, טווח 0.104-7.32, בלי תוויות טיפול. שיטוח של טבלה רחבה. דורש חילוץ מחדש עם עמודת הטיפול.
- rmt_32952899 (פריט 12): `yield_pct=88.74 au` — יחידה שגויה + off-topic. לתקן או להוריד.

**64 האיורים — רק ~13 שווים כיול.** קובץ: `db/evidence_staging/figure_manifest.jsonl` (כולם needs_calibration, בלי plot_type/צירים).
- שווים כיול: foods13213423 p9 (פעילות LOX אפונה), ijbiomac_2025_149984 p5/p6/p9, plants15111639 p4/p7/p11 (GLV µg/kg + OAV), foodchem_2023_137924 p6 (שחרור אוף-פלייבר תחת חום), 1750_3841_70724 p27/p31 (PLS-R).
- להשליך: SEM/זטא/FTIR/DSC/תרשימי-זרימה של rmt_32952899 (~20), פילוגניה של j_plaphy, דיאגרמות 1541_4337_70218, איורים טכנו-כלכליים של j_spc_2026.

**מסקנה אסטרטגית (הסיבה שהרחבנו את הסקר):** הראיות **לא** תומכות במיקוד ב-LOX בלבד.
1. הקסנל אינו סמן ספציפי ל-LOX — אוטו-אוקסידציה מייצרת את אותם אלדהידים (ijbiomac p6 מנגיד LOX מול מצע-שומן). כל 11 המועמדים המספריים הם הקסנל = הטיית חיפוש, לא הוכחת דומיננטיות.
2. בקורפוס כמה מנופים לא-LOX שמפחיתים אוף-פלייבר: תסיסה לקטית (ijbiomac), דה-פלייבורינג/HPP (foods13162608), קשירת פוליפנול-חלבון (foodchem_2025_146333), קואגולציה תרמית (rmt_32952899).
→ המלצה: למסגר את LOX/HPL כ"נקודת כניסה מאופיינת בתוך מודל רב-מסלולי", ולהפוך את Objective 2 לבדיקה שמפרידה תרומת LOX מאוטו-אוקסידציה וממסלול תרמי (פאנל נדיפים מבחין, לא הקסנל לבד; מתחבר למסגור ה-OAV הקיים).

---

## הצעד הבא (בחירת רפי טרם התקבלה)
המתנתי לאישור לפני כתיבה לקבצים. שלוש פעולות מוצעות:
- [ ] (א) לכתוב שדה החלטת-ביקורת ל-`numeric_review.jsonl` (reject + סיבה לכל 12) ולפתוח משימת חילוץ-מחדש ל-Table 2 (foodchem) ו-Table 3 (foods13213423).
- [ ] (ב) לצמצם את `figure_manifest.jsonl` ל-13 האיורים ששווים כיול, לסמן השאר `dropped_offtopic`.
- [ ] (ג) לנסח פסקת עדכון ל-Objective 2 בטיוטה לפי המסקנה הרב-מסלולית.

## פתוח מהטיוטה (מהסשן הקודם)
- [ ] סעיפים 1-7 לעריכה נוספת.
- [ ] `COEFICIENT_APPLICATION_DRAFT.docx` **לא מסונכרן** עם ה-.md (docx מ-14.07 22:58, לפני השכתובים). להחליט אם לרנדר מחדש (pandoc) או ידני.
- [ ] `COEFICIENT_RESEARCH_CONCEPT.md` לא עודכן לפי השכתובים.
- [ ] בדיקת מגבלות מילים בפועל מול הרשום בכותרות.
- [ ] אישור פרופ' בנימין על יעד 40% reduction.
- [ ] מאמר יחיד חסר טקסט מלא: `10.1021/acs.jafc.3c00793` (soy off-flavor) — עדיין ב-access_queue.

---

## מצב Git + סנכרון
- ריפו `Leaf_Literature_Agent` (git נפרד): commit `95c7ebb` נוצר עם כל שינויי הריצה + הביקורת.
- תיקיית COEFICIENT: **לא-עוקבת בגיט**, מסתנכרנת ישירות דרך OneDrive (md/docx).
- קובצי .py/.bat/.json (לא מסתנכרנים ב-OneDrive) → `Leaf_Literature_Agent/session_20260715_pack.zip` (29 קבצים).

## פתיחת סשן חדש במחשב הנייד
1. הרץ `/restore` (מחלץ את `session_20260715_pack.zip`).
2. קרא קובץ זה + זיכרון `project_leaf_lit_agent.md` ו-`project_leaf_protein_extraction.md`.
3. פתח `04_Proposal_Draft/COEFICIENT_APPLICATION_DRAFT.md` (קובץ פעיל) ו-`db/evidence_staging/numeric_review.jsonl` + `figure_manifest.jsonl`.
